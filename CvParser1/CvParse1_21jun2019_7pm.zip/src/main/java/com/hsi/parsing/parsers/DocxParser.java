package com.hsi.parsing.parsers;

import java.io.IOException;
public class DocxParser extends AbstractParser {

	@Override
	public String convert(String dirPath) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

}
