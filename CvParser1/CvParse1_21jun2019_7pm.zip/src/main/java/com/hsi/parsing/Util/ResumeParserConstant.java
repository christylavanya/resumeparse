package com.hsi.parsing.Util;

import org.springframework.stereotype.Component;

/**
 * Created by Siyona on 6/18/2019.
 */
public class ResumeParserConstant {
    public static final String END_POINT_AT_METHOD_LEVEL_FOR_CSV = "/convertToCSV";
    public static final String SUCCESS_MSG_FOR_CSV_CREATE = "Successfully .CSV created in the /temp folder";
    public static final String END_POINT_AT_METHOD_LEVEL_CANDIDATE_DETAILS = "/getCandidateDetails";
    public static final String SUCCESS_MSG_FOR_DEATILD_FROM_CSV = "Successfully Candidate Details Retrieved From .CSV file";
    public static final String FILE_PATH = "filePath";
    public static final String LOG_FOR_ENTRY_FOR_CONVERTCSVFORMAT_METHOD = "convertToCSVFormat method starts";
    public static final String LOG_FOR_ENTRY_FOR_GETCANDIDATEDETAILS_METHOD = "getCandidateDetails method starts";



}
