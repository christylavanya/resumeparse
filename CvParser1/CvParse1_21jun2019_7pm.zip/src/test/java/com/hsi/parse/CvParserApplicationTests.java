package com.hsi.parse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvParserApplicationTests {

	@Test
	void contextLoads() {
	}

}
